package com.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

@Component
@Controller

public class loginControl {

	
	@RequestMapping(value="/login", method=RequestMethod.POST)
    public ModelAndView login(HttpServletRequest request,@RequestParam("name")String name,@RequestParam("password")String password)  
    {  
			
       
		if(password.equals("11"))
		{  	
			
			request.getSession().setAttribute("user",name);
			System.out.println("Welcome, "+name); 
            return new ModelAndView("1.jsp");
		}
		else
		{
            String msg = "Invalid credentials";
            return new ModelAndView("error.jsp", "msg", msg);

		}
  
        
    }     
	
	
	@RequestMapping(value="/logout")
    public ModelAndView logout(HttpServletRequest request,HttpServletResponse response)
    {
		
		
		if(request.getSession().getAttribute("user")==null)
		{
			return new ModelAndView("redirect:/");
		}else {
            
		
		request.getSession().setAttribute("user",null);
		request.getSession().invalidate();
		
		
		
		response.setHeader("Cache-Control", "no-cache");
	    response.setHeader("Cache-Control", "no-store");
	    response.setHeader("Pragma", "no-cache");
	    response.setDateHeader("Expires", 0);
	    return new ModelAndView("redirect:/");
		}
		
		
    }
	
	
	
	@RequestMapping(value="/next")
    public ModelAndView next(ModelAndView model,HttpServletRequest request)
    {
		if(request.getSession().getAttribute("user")==null)
		{
			return new ModelAndView("redirect:/");
		}else {
            
            
            model.setViewName("2.jsp");
            return model;
        }
        
    }
	
	
	
	
	/*@RequestMapping(value = "/logout")
    public ModelAndView logout(HttpSession session) {
             String msg = null;
      session.invalidate();
      ModelAndView mv1= new ModelAndView();
      mv1.addObject("user", msg);
      mv1.setViewName("login.jsp");
      return mv1;
    }*/

	
	
}


