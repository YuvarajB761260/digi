package com;

import java.util.Scanner;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class TestClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Enter bike type : ");
		String bikeName=new Scanner(System.in).next();
		//Resource resource =new ClassPathResource("beans.xml");
		//BeanFactory factory=new XmlBeanFactory(resource);
		
		ApplicationContext factory=new ClassPathXmlApplicationContext("beans.xml");
		
		BajajBike bike =(BajajBike) factory.getBean(bikeName);
		bike.display();
	}

}
