package com;

public interface BajajBike {
	
	public void display();
}
