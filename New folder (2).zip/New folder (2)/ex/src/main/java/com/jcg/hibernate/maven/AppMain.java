package com.jcg.hibernate.maven;
 
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
 

//https://examples.javacodegeeks.com/enterprise-java/hibernate/hibernate-maven-example/
public class AppMain {
 
    static User userObj;
    static Session sessionObj;
    static SessionFactory sessionFactoryObj;
 
    private static SessionFactory buildSessionFactory() {
        // Creating Configuration Instance & Passing Hibernate Configuration File
        Configuration configObj = new Configuration();
        configObj.configure("hibernate.cfg.xml");
 
        // Since Hibernate Version 4.x, ServiceRegistry Is Being Used
        ServiceRegistry serviceRegistryObj = new StandardServiceRegistryBuilder().applySettings(configObj.getProperties()).build(); 
 
        // Creating Hibernate SessionFactory Instance
        sessionFactoryObj = configObj.buildSessionFactory(serviceRegistryObj);
        return sessionFactoryObj;
    }
 
    /*public static void main(String[] args) {
        System.out.println(".......Hibernate Maven Example.......\n");
        try {
            sessionObj = buildSessionFactory().openSession();
            sessionObj.beginTransaction();
 
            for(int i = 301; i <= 305; i++) {
                userObj = new User();
                userObj.setUserid(i);
                userObj.setUsername("Editor " + i);
                userObj.setCreatedBy("Administrator");
                userObj.setCreatedDate(new Date());
 
                sessionObj.save(userObj);
            }
            System.out.println("\n.......Records Saved Successfully To The Database.......\n");
 
            // Committing The Transactions To The Database
            sessionObj.getTransaction().commit();
        } catch(Exception sqlException) {
            if(null != sessionObj.getTransaction()) {
                System.out.println("\n.......Transaction Is Being Rolled Back.......");
                sessionObj.getTransaction().rollback();
            }
            sqlException.printStackTrace();
        } finally {
            if(sessionObj != null) {
                sessionObj.close();
            }
        }
    }*/
    
    public static void main(String[] args) {
        System.out.println(".......Hibernate Maven Example.......\n");
        try {
                    sessionObj = buildSessionFactory().openSession();
                    sessionObj.beginTransaction();


                    /*
                    * 1 = For storing data or insert data in the table.
                    * 2 = Fetchgin the data from the database based on key.
                    * 3 = Fetching all the records using HQL.  Rather than table name, you use the Objects.
                    * 4 = update based on primary key.
                    * 
                    */
                    int operation = 4;
                    switch(operation)
                    {
                    
                    
                    case 1: //For inserting data into the table...

                                for(int i = 101; i <= 105; i++) {
                                            userObj = new User();
                                            userObj.setUserid(i);
                                            userObj.setUsername("Editor " + i);
                                            userObj.setCreatedBy("Administrator");
                                            userObj.setCreatedDate(new Date());

                                            sessionObj.save(userObj);
                                }
                                System.out.println("\n.......Records Saved Successfully To The Database.......\n");

                                // Committing The Transactions To The Databases
                                sessionObj.getTransaction().commit();
                                break;
                                
                                
                                
                                
                    case 2 : //For fetching based on key value. i.e., where user_id = 101.
                                     //This is like Select * from user where user_id = 101.
                                User obj = (User) sessionObj.get (User.class, 105);
                                
                                System.out.println("Id "+obj.getUserid()+
                                                   "\nName " + obj.getUsername()+
                                                   "\nEditor "+obj.getCreatedBy()+
                                                   "\nCreated date "+obj.getCreatedDate());
                                break;
                                
                                
            
                    case 3: 
                                // Hibernate Query Language (HQL) is an object-oriented query language, similar to SQL, 
                                //but instead of operating on tables and columns, HQL works with persistent objects and their 
                                //properties. HQL queries are translated by Hibernate into conventional SQL queries, 
                                //which in turns perform action on database.  You can write all the SQLs here.  Rather than specifying table name
                                //specify the Object name.  You can use, Select, insert, update, delete etc.,
                                String hql = "FROM User";
                                Query query = sessionObj.createQuery(hql);
                                List<User> results = query.list();
                                
                                for (User userObj : results)
                                {
                                            System.out.println("Id "+userObj.getUserid()+
                                       " Name " + userObj.getUsername()+
                                       " Editor "+userObj.getCreatedBy()+
                                       " Created date "+userObj.getCreatedDate());

                                            
                                }
                                break;
                                
                                
                                
                    case 4 : //Update the record based on primary key.
                                User userObj = (User) sessionObj.get (User.class, 105);
                                userObj.setUsername("yuvi");
                                userObj.setCreatedDate(new Date());
                    
                                sessionObj.update(userObj);
                                sessionObj.getTransaction().commit();
                                break;
                                
                    }
                    
                    
        } catch(Exception sqlException) {
                    if(null != sessionObj.getTransaction()) {
                                System.out.println("\n.......Transaction Is Being Rolled Back.......");
                                sessionObj.getTransaction().rollback();
                    }
                    sqlException.printStackTrace();
        } finally {
                    if(sessionObj != null) {
                                sessionObj.close();
                    }

        }

}

}