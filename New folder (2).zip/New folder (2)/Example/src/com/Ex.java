package com;

class A
{
	int x;
	
}
public class Ex {

	public static int countChar(String str, char c)
	{
	    int count = 0;

	    for(int i=0; i < str.length(); i++)
	    {    if(str.charAt(i) == c)
	            count++;
	    }

	    return count;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello");
		String a="Intaearnal";
		int z=Ex.countChar(a,'a');
		System.out.println(z);
		
	}

}
