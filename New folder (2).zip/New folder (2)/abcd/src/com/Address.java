package com;

public class Address {

	private String state;
	private String city;
	private int pin;
	
	
	
	public Address(String state, String city, int pin) {
		super();
		this.state = state;
		this.city = city;
		this.pin = pin;
	}



	@Override
	public String toString()
	{
		System.out.println("state : "+state);
		System.out.println("city : "+city);
		System.out.println("pin : "+pin);

		return "";
	}

}
