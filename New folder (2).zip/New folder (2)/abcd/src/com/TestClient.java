package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext ctx=new ClassPathXmlApplicationContext("beans.xml");
		Object obj=ctx.getBean("student");
		System.out.println(obj);
		
		System.out.println("++++++++++++++++");
		
		Object obj1=ctx.getBean("sch");
		System.out.println(obj1);
		
		System.out.println("----------------");
		
		Object obj2=ctx.getBean("address");
		System.out.println(obj2);
	}

}
