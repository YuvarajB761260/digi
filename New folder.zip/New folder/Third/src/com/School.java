package com;

public class School {

	private String schoolname;
	private int standard; 
	private Address addr;
	public School(String schoolname, int standard, Address addr) {
		super();
		this.schoolname = schoolname;
		this.standard = standard;
		this.addr = addr;
	}
	
	@Override
	public String toString() {
		
		System.out.println("schoolname : "+schoolname);
		System.out.println("standard : "+standard);
		//System.out.println("addr : ");
		System.out.println(addr);

		return "";
	}
	
	
}
