package com;

public class Student {

	private int rollno;
	private String name;
	private int age;
	private School school;
	
	
	public Student(int rollno, String name, int age, School school) {
		super();
		this.rollno = rollno;
		this.name = name;
		this.age = age;
		this.school = school;
	}


	@Override
	public String toString() {
		
		System.out.println("rollno : "+rollno);
		System.out.println("name : "+name);
		System.out.println("age : "+age);
		//System.out.println("school : ");
		System.out.println(school);
		
		return "";
	}


	
	
	
}
