package com.service;

import java.util.List;
 
import org.apache.log4j.Logger;
import org.hibernate.query.Query;
import org.springframework.orm.hibernate5.HibernateTemplate;
 
import com.bean.Register;
 
public class AuthService {
 
    private HibernateTemplate hibernateTemplate;
    private static Logger log = Logger.getLogger(AuthService.class);
 
    private AuthService() { }
 
    public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
        this.hibernateTemplate = hibernateTemplate;
    }
 
    @SuppressWarnings( { "unchecked", "deprecation" } )
    public boolean insertUser(Register u)
    {
    	try
    	{    	
    	
    	System.out.println("Before Entering Data");
    	boolean isValidUser=true;

    	System.out.println(u.getEmail());
    	

    	hibernateTemplate.delete
    	
    	hibernateTemplate.save(u);
    	
    	
  /*  	String hql = "from Register";

		

		List<Register> list = (List<Register>) hibernateTemplate.find(hql);
		
		for (Register regObj : list)
		{
			
			System.out.println(regObj.getFn());
		}*/
    	
    	
    	System.out.println("After Entering Data");
    	
    	return isValidUser;
    	}
    	catch (Exception ex)
    	{
    		System.out.println(ex);
    		ex.printStackTrace();
    		
    	}
		return false;
    }
    
    
    
    public boolean delete(String uid) {
        log.info("Checking the user in the database");
        boolean isValidUser = true;
       String name="";
        String sqlQuery = "from User u where u.userid=? and u.password=? and u.type=?";
        System.out.println("In the authentication service...user entered data " + uid );
        try {
            hibernateTemplate.find(sqlQuery, uid);
            System.out.println("After deleting");
            
            return isValidUser;
           
        }
        catch (Exception ex)
    	{
    		System.out.println(ex);
    		ex.printStackTrace();
    		
    	}
		return false;
    }

}