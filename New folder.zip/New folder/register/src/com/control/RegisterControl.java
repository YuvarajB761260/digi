package com.control;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.bean.Register;
import com.service.AuthService;
 
@Component
@Controller

public class RegisterControl {
	
	@RequestMapping("/")  
    public String display()  
    {  
        return "register";  
    }     
 
    @Autowired
    private AuthService authenticateService;            // This will auto-inject the authentication service into the controller.
 
    private static Logger log = Logger.getLogger(RegisterControl.class);
    
    
 
    // Checks if the user credentials are valid or not.
    @RequestMapping(value = "/validate", method = RequestMethod.POST)
    public ModelAndView insertUsr(@RequestParam("fn")String fn, 
    		@RequestParam("ln")String ln, 
    		@RequestParam("age")int age, 
    		@RequestParam("gender")String gender, 
    		@RequestParam("contact")double contact, 
    		@RequestParam("userid")String userid, 
    		@RequestParam("mail")String mail,
    		@RequestParam("password")String password,
    		@RequestParam("type")String type) {
    	
    	
    	System.out.println(age);
    	Register r=new Register();
    	r.setFn(fn);
    	r.setAge(age);
    	r.setContact(contact);
    	r.setEmail(mail);
    	r.setUserid(userid);
    	r.setGender(gender);
    	r.setLn(ln);
    	r.setPassword(password);
    	r.setType(type);
        String msg = "";
        System.out.println(r.getType());
        boolean isValid = authenticateService.insertUser(r);
        log.info("Is user valid?= " + isValid);
        
        System.out.println("In the controller..");
 
        if(isValid) {
            msg = "inserted successfully !";
            return new ModelAndView("result", "output", msg);
            
        } 
        else {
            msg = "not inserted";
            return new ModelAndView("result", "output", msg);
        }
        
 
      
    }
    
    
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    public ModelAndView validateUsr(@RequestParam("userid")String userid ) {
        String msg = "";
        String isValid = authenticateService.delete(userid);
        log.info("Is user valid?= " + isValid);

        if(isValid!="null") {
            msg = "Welcome " + isValid + "!";
            return new ModelAndView("result", "output", msg);
            
        } else {
            msg = "Invalid credentials";
            return new ModelAndView("login","output",msg);
        }

    }

}